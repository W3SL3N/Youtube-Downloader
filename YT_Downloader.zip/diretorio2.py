import os
from pathlib import Path

class Diretorio:

    @staticmethod
    def existe_disco(disco):

        procura = disco[0:3]

        existe = os.path.isdir(procura)

        return existe

    @staticmethod
    def verifica_sintaxe(caminho):

        caracteres_proibidos = [':', '*', '?', '"', '<', '>', '|']
        compara = set(caminho[3:]) & set(caracteres_proibidos)

        if len(compara) > 0:
            return False
        else:
            return True

    def diretorio(self, nome):

        amarelo = '\033[1;33m'
        reset = '\033[0;0m'

        caminho = Path(Path.home(), 'YT Downloader', f'{nome}')

        print(f'\nPasta padrão para o download: {caminho}')

        cond = 0

        while cond == 0:

            sim = ['sim', 's']
            nao = ['não', 'nao', 'n']
            pergunta = input('Mudar pasta?' + (amarelo + '(S/n)' + reset) + ': ').lower().strip()

            diretorio = Path(Path.home(), 'YT Downloader', f'{nome}')
            diretorio = os.path.normpath(diretorio)
            diretorio = os.path.normcase(diretorio)

            if pergunta in nao:
                return diretorio

            if pergunta in sim:
                cond = 0

                while cond == 0:

                    diretorio = (input(amarelo + '\n>>> ' + reset).strip())


                    existe_disco = Diretorio.existe_disco(diretorio)

                    if existe_disco:
                        verifica_sintaxe = Diretorio.verifica_sintaxe(diretorio)

                        if verifica_sintaxe == True:
                            return diretorio

                        else:
                            print('\nO nome da pasta não pode conter esses caracteres:', ':', '*', '?', '"', "'", '<', '>',
                                  '|')
                            continue

                    if not existe_disco:
                        print('\nO disco local informado não existe...')
                        continue

                    cond += 1

            else:
                continue

            cond += 1


import os
from pathlib import Path


class Diretorio:

    @staticmethod
    def existe_disco(disco):

        procura = disco[0:2]

        existe = os.path.isdir(procura)

        return existe

    @staticmethod
    def verifica_sintaxe(caminho):

        caracteres_proibidos = [':', '*', '?', '"', '<', '>', '|']
        compara = set(caminho[3:]) & set(caracteres_proibidos)

        if len(compara) > 0:
            return False
        else:
            return True

    @staticmethod
    def existe_diretorio(caminho):
        return os.path.isdir(caminho)

    def diretorio(self, nome):

        amarelo = '\033[1;33m'
        reset = '\033[0;0m'

        caminho = Path(Path.home(), 'YT Downloader', f'{nome}')

        print(f'\nPasta padrão para o download: {caminho}')

        cond = 0

        while cond == 0:

            sim = ['sim', 's']
            nao = ['não', 'nao', 'n']
            pergunta = input('Mudar pasta?' + (amarelo + '(S/n)' + reset) + ': ').lower().strip()

            diretorio = Path(Path.home(), 'YT Downloader', f'{nome}')
            diretorio = os.path.normpath(diretorio)

            if pergunta in nao:
                return diretorio

            if pergunta in sim:
                cond = 0

                while cond == 0:

                    diretorio = (input(amarelo + '\n>>> ' + reset).strip())

                    existe_disco = Diretorio.existe_disco(diretorio)

                    if existe_disco:
                        verifica_diretorios = Diretorio.existe_diretorio(diretorio)

                        if verifica_diretorios == True:
                            return diretorio

                        else:
                            return os.mkdir(diretorio)

                    if not existe_disco:
                        print('\nO disco local informado não existe...')
                        continue

                    cond += 1

            else:
                continue

            cond += 1
